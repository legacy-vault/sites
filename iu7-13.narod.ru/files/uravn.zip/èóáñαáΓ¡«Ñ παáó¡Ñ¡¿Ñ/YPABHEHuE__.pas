unit YPABHEHuE__;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls;

type
  TMainForm = class(TForm)
    Label1: TLabel;
    ka: TLabeledEdit;
    kb: TLabeledEdit;
    kc: TLabeledEdit;
    Button1: TButton;
    Result: TMemo;
    GroupBox1: TGroupBox;
    Label2: TLabel;
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  MainForm: TMainForm;

implementation

{$R *.dfm}

procedure TMainForm.Button1Click(Sender: TObject);
var
  Data  : array [1..3] of Boolean;
  A,B,C : Real;
  D     : Real;
  X1,X2 : Real;
  I     : Integer;
  Ch    : Char;
begin
// ??????: | A=0 | B=6 | C=8  | => | X=-1.33 (???????? ??-?)   |
// ??????: | A=1 | B=2 | C=1  | => | X=-1                      |
// ??????: | A=1 | B=0 | C=-9 | => | X1=3 ; X2=-3              |
// ??????: | A=3 | B=0 | C=7  | => | ??? ?????????????? ?????? |
// ??????: | A=0 | B=0 | C=0  | => | ??????????? ?????         |
//                                 | ?????????????? ??????     |

  for I:=1 to 3 do Data[I]:=TRUE;
  if ka.Text = '' then Data[1] := FALSE;
  if kb.Text = '' then Data[2] := FALSE;
  if kc.Text = '' then Data[3] := FALSE;

  for I:=1 to Length(ka.Text) do begin
    Ch := ka.Text[I];
    Data[1] := Data[1] and ((Ch='0')or(Ch='1')or(Ch='2')or(Ch='3')or(Ch='4')or(Ch=',')
             or(Ch='5')or(Ch='6')or(Ch='7')or(Ch='8')or(Ch='9')or(Ch='-')or(Ch='.'));
  end;
  for I:=1 to Length(kb.Text) do begin
    Ch := kb.Text[I];
    Data[2] := Data[2] and ((Ch='0')or(Ch='1')or(Ch='2')or(Ch='3')or(Ch='4')or(Ch=',')
             or(Ch='5')or(Ch='6')or(Ch='7')or(Ch='8')or(Ch='9')or(Ch='-')or(Ch='.'));
  end;
  for I:=1 to Length(kc.Text) do begin
    Ch := kc.Text[I];
    Data[3] := Data[3] and ((Ch='0')or(Ch='1')or(Ch='2')or(Ch='3')or(Ch='4')or(Ch=',')
             or(Ch='5')or(Ch='6')or(Ch='7')or(Ch='8')or(Ch='9')or(Ch='-')or(Ch='.'));
  end;
  if (Data[1] and Data[2] and Data[3]) then begin
   Result.Lines.Add('A='+ka.Text+' ; B='+kb.Text+' ; C='+kc.Text);
   A:=StrToFloat(ka.Text);
   B:=StrToFloat(kb.Text);
   C:=StrToFloat(kc.Text);
  if A <> 0 then
    begin
      D:=B*B - 4*A*C;

      if D < 0 then Result.Lines.Add('��� �������������� ������.');

      if D = 0 then
        begin
          X1:=(-B)/(2*A);
          Result.Lines.Add('2 �������������� ����� : �1=�2='+FloatToStr(X1));
        end;

      if D > 0 then
        begin
          X1:=(-B + Sqrt(D)) / (2*A);
          X2:=(-B - Sqrt(D)) / (2*A);
          Result.Lines.Add('2 �����: �1='+FloatToStr(X1)+' ; �2='+FloatToStr(X2));

        end;
    end
  else
    begin
      if B <> 0 then
        begin
          X1:=-C/B;
          Result.Lines.Add('��������� ��������, ������ �='+FloatToStr(X1));
        end
      else
        begin
          if C=0 then
            Result.Lines.Add('����������� ����� �������������� ������.')
          else
            Result.Lines.Add('��� �������!');
        end;
    end;
    Result.Lines.Add('');
  end
  else MessageDlg('������ ������!',mtError,[mbOk],0);


end;

end.
