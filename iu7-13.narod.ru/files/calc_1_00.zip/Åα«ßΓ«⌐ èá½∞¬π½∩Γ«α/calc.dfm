object Form1: TForm1
  Left = 398
  Top = 788
  BorderIcons = [biSystemMenu, biMinimize]
  BorderStyle = bsSingle
  Caption = #1055#1088#1086#1089#1090#1086#1081' '#1050#1072#1083#1100#1082#1091#1083#1103#1090#1086#1088
  ClientHeight = 99
  ClientWidth = 446
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesktopCenter
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 137
    Top = 26
    Width = 4
    Height = 16
    Caption = '/'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 296
    Top = 26
    Width = 7
    Height = 16
    Caption = '='
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object operand1: TLabeledEdit
    Left = 14
    Top = 24
    Width = 112
    Height = 21
    EditLabel.Width = 53
    EditLabel.Height = 13
    EditLabel.Caption = #1054#1087#1077#1088#1072#1085#1076' 1'
    LabelPosition = lpAbove
    LabelSpacing = 3
    TabOrder = 0
    OnKeyPress = operand1KeyPress
  end
  object operand2: TLabeledEdit
    Left = 167
    Top = 24
    Width = 112
    Height = 21
    EditLabel.Width = 53
    EditLabel.Height = 13
    EditLabel.Caption = #1054#1087#1077#1088#1072#1085#1076' 2'
    LabelPosition = lpAbove
    LabelSpacing = 3
    TabOrder = 1
    OnKeyPress = operand2KeyPress
  end
  object result: TLabeledEdit
    Left = 317
    Top = 24
    Width = 112
    Height = 21
    EditLabel.Width = 52
    EditLabel.Height = 13
    EditLabel.Caption = #1056#1077#1079#1091#1083#1100#1090#1072#1090
    LabelPosition = lpAbove
    LabelSpacing = 3
    TabOrder = 2
  end
  object Button1: TButton
    Left = 21
    Top = 62
    Width = 76
    Height = 24
    Caption = 'div'
    TabOrder = 3
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 131
    Top = 61
    Width = 75
    Height = 25
    Caption = '-'
    TabOrder = 4
    OnClick = Button2Click
  end
  object Button3: TButton
    Left = 242
    Top = 61
    Width = 75
    Height = 25
    Caption = #1054#1095#1080#1089#1090#1080#1090#1100
    TabOrder = 5
    OnClick = Button3Click
  end
  object Button4: TButton
    Left = 353
    Top = 62
    Width = 75
    Height = 25
    Caption = #1042#1099#1093#1086#1076
    TabOrder = 6
    OnClick = Button4Click
  end
end
