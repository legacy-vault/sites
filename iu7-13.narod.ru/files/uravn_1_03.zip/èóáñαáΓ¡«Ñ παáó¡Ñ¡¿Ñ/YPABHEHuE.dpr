program YPABHEHuE;

uses
  Forms,
  YPABHEHuE__ in 'YPABHEHuE__.pas' {MainForm};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TMainForm, MainForm);
  Application.Run;
end.
