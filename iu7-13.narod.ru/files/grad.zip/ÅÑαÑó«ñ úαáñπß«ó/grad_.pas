unit grad_;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, ComCtrls;

type
  TForm1 = class(TForm)
    Label1: TLabel;
    RG1: TRadioGroup;
    RG2: TRadioGroup;
    Button1: TButton;
    Edit1: TEdit;
    Result: TMemo;
    GroupBox1: TGroupBox;
    Button2: TButton;
    UpDown1: TUpDown;
    SaveDialog1: TSaveDialog;
    procedure Button1Click(Sender: TObject);
    procedure Edit1KeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure Button2Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

procedure TForm1.Button1Click(Sender: TObject);
var
  Grads     : array [0..2] of String;
  NewResult : String;
  Znak      : Char;
  Gr        : Real;
  DataOk    : Boolean;
  I         : Integer;
  Ch        : Char;
begin
  DataOk := TRUE;
  if Edit1.Text = '' then DataOk := FALSE;
  for I:=1 to Length(Edit1.Text) do begin
    Ch := Edit1.Text[I];
    DataOk := DataOk and ((Ch='0')or(Ch='1')or(Ch='2')or(Ch='3')or(Ch='4')or(Ch=',')
             or(Ch='5')or(Ch='6')or(Ch='7')or(Ch='8')or(Ch='9')or(Ch='-')or(Ch='.'));
  end;

  if DataOk then begin                                   
  Gr := StrToFloat(Edit1.Text);
  Znak := '�';
  Grads[0]:=' '+Znak+'C';
  Grads[1]:=' '+Znak+'F';
  Grads[2]:=' '+Znak+'R';
  NewResult := '';
  if RG1.ItemIndex = RG2.ItemIndex then
   NewResult:= Edit1.Text;
  if (RG1.ItemIndex = 0) and (RG2.ItemIndex = 1) then
   NewResult:=FloatToStr(1.8*Gr + 32);
  if (RG1.ItemIndex = 0) and (RG2.ItemIndex = 2) then
   NewResult:=FloatToStr(0.8*Gr);

  if (RG1.ItemIndex = 1) and (RG2.ItemIndex = 0) then
   NewResult:=FloatToStr((Gr-32) / 1.8);
  if (RG1.ItemIndex = 1) and (RG2.ItemIndex = 2) then
   NewResult:=FloatToStr((Gr-32)/1.8*0.8);

  if (RG1.ItemIndex = 2) and (RG2.ItemIndex = 0) then
   NewResult:=FloatToStr(Gr*1.25);
  if (RG1.ItemIndex = 2) and (RG2.ItemIndex = 1) then
   NewResult:=FloatToStr(Gr*1.25*1.8+32);

  Result.Lines.Add(Edit1.Text+' '+Grads[RG1.ItemIndex]+' = '+NewResult+' '+Grads[RG2.ItemIndex]+' ');
  end
  else
   MessageDlg('������ ������!',mtError,[mbOk],0);

end;


procedure TForm1.Edit1KeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
 if (Ord(Key)=13) then Button1Click(Self);
end;


procedure TForm1.Button2Click(Sender: TObject);
var
 Res_File : TextFile;
 I        : Integer;
begin
 SaveDialog1.Execute;
 if (SaveDialog1.FileName<>'') then begin
   //������ � ����
   AssignFile(Res_File, SaveDialog1.FileName);
   Rewrite(Res_File);
   Write(Res_File, Result.Lines.Text);
   CloseFile(Res_File);
 end;
end;

end.
