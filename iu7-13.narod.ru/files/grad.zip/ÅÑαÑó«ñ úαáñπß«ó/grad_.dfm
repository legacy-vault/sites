object Form1: TForm1
  Left = 238
  Top = 143
  Width = 362
  Height = 397
  BorderIcons = [biSystemMenu, biMinimize]
  Caption = #1055#1077#1088#1077#1074#1086#1076' '#1075#1088#1072#1076#1091#1089#1086#1074
  Color = clBtnFace
  Font.Charset = RUSSIAN_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesktopCenter
  PixelsPerInch = 96
  TextHeight = 16
  object Label1: TLabel
    Left = 64
    Top = 8
    Width = 216
    Height = 16
    Caption = #1057#1082#1086#1083#1100#1082#1086' '#1075#1088#1072#1076#1091#1089#1086#1074' '#1085#1091#1078#1085#1086' '#1087#1077#1088#1077#1074#1077#1089#1090#1080'?'
  end
  object GroupBox1: TGroupBox
    Left = 16
    Top = 216
    Width = 321
    Height = 129
    Caption = #1056#1077#1079#1091#1083#1100#1090#1072#1090#1099
    TabOrder = 5
  end
  object RG1: TRadioGroup
    Left = 19
    Top = 64
    Width = 137
    Height = 105
    Caption = #1053#1072#1095#1072#1083#1100#1085#1072#1103' '#1096#1082#1072#1083#1072
    Ctl3D = True
    ItemIndex = 0
    Items.Strings = (
      #1062#1077#1083#1100#1089#1080#1081
      #1060#1072#1088#1077#1085#1075#1077#1081#1090
      #1056#1077#1072#1084#1102#1088)
    ParentCtl3D = False
    TabOrder = 0
  end
  object RG2: TRadioGroup
    Left = 189
    Top = 64
    Width = 136
    Height = 105
    Caption = #1050#1086#1085#1077#1095#1085#1072#1103' '#1096#1082#1072#1083#1072
    ItemIndex = 1
    Items.Strings = (
      #1062#1077#1083#1100#1089#1080#1081
      #1060#1072#1088#1077#1085#1075#1077#1081#1090
      #1056#1077#1072#1084#1102#1088)
    TabOrder = 1
  end
  object Button1: TButton
    Left = 16
    Top = 185
    Width = 147
    Height = 25
    Caption = #1055#1077#1088#1077#1074#1077#1089#1090#1080
    TabOrder = 2
    OnClick = Button1Click
  end
  object Edit1: TEdit
    Left = 152
    Top = 32
    Width = 49
    Height = 24
    TabOrder = 3
    Text = '0'
    OnKeyDown = Edit1KeyDown
  end
  object Result: TMemo
    Left = 24
    Top = 240
    Width = 305
    Height = 89
    ScrollBars = ssVertical
    TabOrder = 4
  end
  object Button2: TButton
    Left = 186
    Top = 184
    Width = 145
    Height = 25
    Caption = #1057#1086#1093#1088#1072#1085#1080#1090#1100' '#1088#1077#1079#1091#1083#1100#1090#1072#1090#1099
    TabOrder = 6
    OnClick = Button2Click
  end
  object UpDown1: TUpDown
    Left = 201
    Top = 32
    Width = 13
    Height = 24
    Associate = Edit1
    Min = -32768
    Max = 32767
    Position = 0
    TabOrder = 7
    Wrap = False
  end
  object SaveDialog1: TSaveDialog
    DefaultExt = 'txt'
    Filter = #1058#1077#1082#1089#1090#1086#1074#1099#1077' '#1060#1072#1081#1083#1099' (*.txt)|*.txt|'#1042#1089#1077' '#1060#1072#1081#1083#1099' (*.*)|*.*'
    Left = 312
    Top = 8
  end
end
